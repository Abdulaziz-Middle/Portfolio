import React from 'react';
import { NavLink } from 'react-router-dom';
function NotFaund() {
  return (
    <div style={{paddingTop:"400px",paddingBottom:"200px",textAlign:"center",alignItems:"center"}}>
        <h1>NotFaund</h1>
        <NavLink to={"/"}>Back To Home</NavLink>
    </div>
  )
}
export default NotFaund