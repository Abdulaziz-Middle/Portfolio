import React, { useContext, useEffect, useState } from 'react';
import "./Shop.css";
import { BsFillBasketFill } from "react-icons/bs";
import { FiGrid, FiAlignJustify } from "react-icons/fi";
import { ABDULAZIZBEK_CONTEXT } from '../../Context/Context';
import Box from '@mui/material/Box';
import { AiFillLike, AiOutlineLike } from "react-icons/ai";
import Slider from '@mui/material/Slider';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { LuGitCompare } from "react-icons/lu";
import { FcLike } from "react-icons/fc";
import { useNavigate } from 'react-router-dom';
import ReactPaginate from 'react-paginate';
function Shop() {
  const handleChange = (event,newValue) => {
    setValue(newValue);
  };
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);
  const itemsPerPage = 1;
  const { shop, search, handleCart, handleLike, setShop, filterData, setName, yulduzchaas, narxchasiSS, setNarxchasiSS, handleDeleteCart, setYulduzchaas, priceNarx, setPriceNarx, tab, setTab, filterText, chekbook, setChekbook, setFilterText, } = useContext(ABDULAZIZBEK_CONTEXT);
  const Abdulaziz = (index) => {
    setTab(index)
  }
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setShop(shop.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(shop.length / itemsPerPage));
  }, [itemOffset, shop]);
  const handlePageClick = (selected) => {
    const newOffset = selected * itemsPerPage;
    setItemOffset(newOffset);
  };
  const [value, setValue] = React.useState([0, 500]);
  const abdulazizbek = useNavigate();
  function handlePages(value) {
    abdulazizbek(`/product/${value.id}`)
  };

  console.log(shop, 'home1');
  const BTNS4 = [`⭐️⭐️⭐️⭐️⭐️`, `⭐️⭐️⭐️⭐️`, `⭐️⭐️⭐️`, `⭐️⭐️`, `⭐️`]
  const BTNS3 = ["0-5", "1-2", "2-3", "3-4", "4-5", "5+"];
  const BTNS2 = ["apple", "samsung", "lg", "huawei", "lenovo", "nokia"];
  const BTNS1 = ["", "TV & Audio", "Smartphones", "Laptops & PCs", "Gadgets", "Photo & Video", "Gifts", "Books", "Toys"];
  return (
    <div className='fiewfuwhnu'>
      {
        shop.map((aammmaa) => (
          <div className='SHOPPPS' key={aammmaa}>
            <div className='SHOPPPSDIV1'>
              <div className='aallllaaa'>
                <h4 className='dwhude'>Categories</h4>
                <Accordion className='aallllaaa'>
                  <AccordionSummary className='aallllaaa' expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                    <Typography className='aallllaaa dwhude'>All</Typography>
                  </AccordionSummary>
                  <AccordionDetails className='aallllaaa'>
                    <Typography className='aallllaaa'>
                      {BTNS1.map((btn) => {
                        return (
                          <p
                            key={btn}
                            onClick={() => setFilterText(btn)}
                            className={btn === filterText ? "btnActive aallllaaa dwhude" : "SalomHelloMAMA dwhude aallllaaa"}
                          >
                            {btn === "" ? "All" : btn.toLocaleLowerCase()}
                          </p>
                        );
                      })}
                    </Typography>
                  </AccordionDetails >
                </Accordion >
              </div >
              <div>
                <div className='ehfwiu'>
                  <h1 className='ebwfwb'>Brands</h1>
                  {BTNS2.map((abdulazizbek008) => {
                    return (
                      <div onClick={() => setChekbook(abdulazizbek008)} className='jioejroi' onDoubleClick={() => setChekbook("")} key={abdulazizbek008}>
                        <button
                          className={abdulazizbek008 !== chekbook ? "ejfw" : "crkjogie"}
                          onClick={() => setChekbook(abdulazizbek008)} style={{ cursor: "pointer" }}
                          onDoubleClick={() => setChekbook("")}
                        >
                          <p onDoubleClick={() => setChekbook("")} style={{ cursor: "pointer" }} className={abdulazizbek008 === chekbook ? "oefiehfiuh" : "niuewf"}></p>
                        </button>
                        <p
                          onClick={() => setChekbook("")}
                          className={abdulazizbek008 === chekbook ? "dwdwefe" : ""}
                        >
                          {abdulazizbek008 === "" ? "" : abdulazizbek008.toLocaleLowerCase()}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className='ehfwiu'>
                <h1 style={{ cursor: "pointer" }} onClick={() => setNarxchasiSS("")} className='ebwfwb' >Price</h1>
                {
                  BTNS3.map((abdulazizbekk_amd) => {
                    return (
                      <div className='jioejroi' key={abdulazizbekk_amd}>
                        <button
                          className={abdulazizbekk_amd !== narxchasiSS ? "ejfw" : "crkjogie"}
                          onClick={() => setNarxchasiSS(abdulazizbekk_amd)}
                          onDoubleClick={() => setNarxchasiSS("")}>
                          <p onDoubleClick={() => setNarxchasiSS("")} className={abdulazizbekk_amd === narxchasiSS ? "oefiehfiuh" : "niuewf"}></p>
                        </button>
                        <p
                          className={abdulazizbekk_amd === narxchasiSS ? "dwdwefe" : ""}
                          onClick={() => setNarxchasiSS(abdulazizbekk_amd)}
                          onDoubleClick={() => setNarxchasiSS("")}>
                          {abdulazizbekk_amd === "" ? "All" : abdulazizbekk_amd.toLocaleLowerCase()}
                        </p>
                      </div>
                    )
                  })
                }
              </div>
              <div>
              </div>
              <div className='lkeuwifuwg'>
                <div className='Chekbook xzxz sckjejhb'>
                  <input type="checkbox" className='ejfhwuygfuwy' />
                  <p className='ejfhwuygfuwy dwnebfwbhufb'>Price interval</p>
                </div>
                <Box sx={{ width: 220 }}>
                  <Slider
                    value={value}
                    onChange={handleChange}
                    valueLabelDisplay="auto"
                    min={0}
                    max={500}
                  />
                </Box>
                <p className='dwnebfwbhufb'>Price:  $0  -  $0,500</p>
              </div>
              <div className='fwfiwuub'>
                <p onClick={() => setPriceNarx("")} style={{ cursor: "pointer" }} className='Brands lemfw dkewjnj fweiuh'>Colours</p>
                <div className='Button_S_DivdweWWW'>
                  <button onClick={() => setPriceNarx("000000")} className="Button1"></button>
                  <button onClick={() => setPriceNarx("FFFFFF")} className="Button2"></button>
                  <button onClick={() => setPriceNarx("319DFF")} className="Button3"></button>
                  <button onClick={() => setPriceNarx("FFDE31")} className="Button4"></button>
                  <button onClick={() => setPriceNarx("FF316A")} className="Button5"></button>
                  <button onClick={() => setPriceNarx("0DA678")} className="Button6"></button>
                  <button onClick={() => setPriceNarx("9E13F3")} className="Button7"></button>
                  <button onClick={() => setPriceNarx("FFAA04")} className="Button8"></button>
                  <button onClick={() => setPriceNarx("FF64DD")} className="ButtoN9"></button>
                  <button onClick={() => setPriceNarx("17D1DD")} className="ButtoN10"></button>
                </div>
              </div>
              <div className='ehfwiu cehiu'>
                <h1 className='ebwfwb'>Rating</h1>
                {
                  BTNS4.map((bbggrf) => {
                    return (
                      <div className='jioejroi' key={bbggrf}>
                        <button
                          className={bbggrf === yulduzchaas ? "ejfw" : "crkjogie"}
                          onClick={() => setYulduzchaas(bbggrf)}
                          onDoubleClick={() => setYulduzchaas("")}>
                          <p onDoubleClick={() => setYulduzchaas("")} className={bbggrf === yulduzchaas ? "oefiehfiuh" : "niuewf"}></p>
                        </button>
                        <p
                          className={bbggrf === yulduzchaas ? "dwdwefe" : ""}
                          onClick={() => setYulduzchaas(bbggrf)}
                          onDoubleClick={() => setYulduzchaas("")}>
                          {bbggrf === "" ? "" : bbggrf.toLocaleLowerCase()}
                        </p>
                      </div>
                    )
                  })
                }
              </div>
            </div>
            <div>
              <div>
                <div className='YYYYFYDRT'>
                  <div>
                    <h1 className='ehfuywgeuy'>Shop</h1>
                  </div>
                  <div className='SHOPLENGTH'>
                    <p className='wdqiwnu'>{filterData.length}</p>
                    <span className='efjiwenfu'>products</span>
                  </div>
                </div>
                <div className='yvy'>
                  <div className='tabsTBAN'>
                    <FiGrid className='AAMMDD' onClick={() => Abdulaziz(2)} />
                    <FiAlignJustify className='AAMMDD' onClick={() => Abdulaziz(1)} />
                  </div>
                </div>
                {
                  filterData && filterData.length > 0 ? (
                    <div>


                      <div className={tab === 1 ? "Shop" : ""}>
                        <div className='Shop1Div'>
                          {filterData
                            .filter((item) => {
                              return search.toLowerCase() === "" ? item : item.name.toLowerCase().includes(search)
                            })
                            .length > 0 ? (
                            filterData.filter((e) => {
                              if (
                                e?.catagory1.includes(filterText) &&
                                value[0] < e.narx &&
                                e.narx <= value[1]
                              ) {
                                return e;
                              }
                            }
                            )
                              .filter((a) => {
                                if (
                                  a?.brand.includes(chekbook)
                                ) {
                                  return a;
                                }
                              })
                              .filter((pricenarxcha) => {
                                if (
                                  pricenarxcha?.rangi.includes(priceNarx)
                                ) {
                                  return pricenarxcha;
                                }
                              })
                              .filter((MMMAAA) => {
                                if (
                                  MMMAAA?.priceee.includes(narxchasiSS)
                                ) {
                                  return MMMAAA;
                                }
                              })
                              .filter((LLALLLA) => {
                                if (
                                  LLALLLA?.Yulduzcha.includes(yulduzchaas)
                                ) {
                                  return LLALLLA;
                                }
                              })
                              .map((home1) => {
                                console.log(home1.like);
                                return (
                                  <div className='AAKKKA' key={home1.id}>
                                    <p className='ShopCardSCataGory'>{home1.catagory1}</p>
                                    <div style={{ cursor: "pointer" }} onClick={() => handlePages(home1)} className='ShopCardSNameDiv'>
                                      <span className='ShopCardSName'>{home1.name}</span>
                                    </div>
                                    <img className='ImG' src={home1.img} alt="" />
                                    <div className='CardSDivPriceADD_TOCARD'>
                                      <div className='CLALLA'>
                                        <div>
                                        <p className='gvfdt'>{home1.narx}</p>
                                        <del className='OYU'>{home1.eski}</del>
                                        </div>
                                        <p className={home1 ? "AiFillLike" : "AiOutlineLike"} onClick={() => handleLike(home1.id)}>
                                          {home1.like ? <AiFillLike /> : <AiOutlineLike />}
                                        </p>
                                      </div>
                                      <div className='CLALLAL'>
                                        <BsFillBasketFill className='jvuguygeruy' onDoubleClick={() => handleDeleteCart(home1.id)} onClick={() => handleCart(home1)} />
                                      </div>
                                    </div>
                                  </div>
                                )
                              }
                              )
                          ) : (
                            <div>
                              <h1>Malumot Yoq</h1>
                            </div>
                          )
                          }
                        </div>
                      </div>
                      <div className={tab === 2 ? "Shop fwfewifweuh" : ""}>
                        <div className='Clalal'>
                          {shop.filter((item) => {
                            return search.toLowerCase() === "" ? item : item.name.toLowerCase().includes(search)
                          })
                            .length > 0 ? (
                            filterData.filter((e) => {
                              if (
                                e?.catagory1.includes(filterText) &&
                                value[0] < e.narx &&
                                e.narx <= value[1]
                              ) {
                                return e;
                              }
                            })
                              .filter((a) => {
                                if (
                                  a?.brand.includes(chekbook)
                                ) {
                                  return a;
                                }
                              })
                              .filter((pricenarxcha) => {
                                if (
                                  pricenarxcha?.rangi.includes(priceNarx)
                                ) {
                                  return pricenarxcha;
                                }
                              })
                              .filter((MMMAAA) => {
                                if (
                                  MMMAAA?.priceee.includes(narxchasiSS)
                                ) {
                                  return MMMAAA;
                                }
                              })
                              .filter((LLALLLA) => {
                                if (
                                  LLALLLA?.Yulduzcha.includes(yulduzchaas)
                                ) {
                                  return LLALLLA;
                                }
                              })
                              .map((home1) => {
                                return (
                                  <div className='euyfuey' key={home1.id}>
                                    <div>
                                      <img className='jbefhb' src={home1.img} alt="" />
                                    </div>
                                    <div>
                                      <div className='efiuhwyuf'>
                                        <p className='efoehui'>{home1.catagory1}</p>
                                        <div className='efuhwui'>
                                          <span style={{ cursor: "pointer" }} onClick={() => handlePages(home1)} className='lfejleihk'>{home1.name}</span>
                                        </div>
                                        <p className='fwehiugwuy'>⭐⭐⭐⭐⭐<p className='fwiueh'>4.9</p><span className='cvlrekrr'>(200)</span></p>
                                        <div>
                                          <div className='jfiehwiu'>
                                            <p className='ijweiufhi'>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                            <p className='ijweiufhi'>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                                            <p className='ijweiufhi'>Ut enim ad minim veniam, quis nostrud exercitation ullamco</p>
                                          </div>
                                        </div>
                                        <p className='feowijfiu'>SKU: 29087645</p>
                                      </div>
                                    </div>
                                    <div className='KGTFYfehuywg'>
                                      <div className='fgueygu'>
                                        <button onClick={() => handlePages(home1)} className='CompareButtondd'>Compare<LuGitCompare className='LuGitCompare' /></button>
                                        <button onClick={() => handleLike(home1.id)} className='kfheiuwhguygyu'>Wishlist<p className={home1 ? "AiFillLike" : "AiOutlineLike"} onClick={() => handleLike(home1.id)}>
                                          {home1.like ? <AiFillLike /> : <AiOutlineLike />}
                                        </p></button>
                                      </div>
                                      <div>
                                        <h1 className='dhieugug'>${home1.narx}</h1>
                                      </div>
                                      <button className='Addefhiuh' onClick={() => handleCart(home1)}>Add to Cart <BsFillBasketFill onClick={() => handleCart(home1)} /></button>
                                    </div>
                                  </div>
                                )
                              })
                          ) : (
                            <div>
                              <h1>Malumot yuq</h1>
                            </div>
                          )
                          }
                        </div>
                      </div>
                    </div>
                  )
                    : (
                      <div></div>
                    )
                }
              </div>
            </div>
          </div>
        ))
      }
      <ReactPaginate
        breakLabel="..."
        nextLabel="Next"
        onPageChange={handlePageClick}
        pageRangeDisplayed={3}
        pageCount={pageCount}
        previousLabel="Previous"
        marginPagesDisplayed={1}
        containerClassName='pagination'
        pageLinkClassName='page-num'
        previousLinkClassName='page-num'
        nextLinkClassName='page-num'
        activeClassName='active'
      />
    </div>
  )
}
export default Shop;