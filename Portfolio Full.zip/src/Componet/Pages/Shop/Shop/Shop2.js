import React from 'react';
function Shop2() {
  return (
    <div>
        <h1>2</h1>
    </div>
  )
}
export default Shop2