import React, { useContext } from 'react';
import { ABDULAZIZBEK_CONTEXT } from '../../Context/Context';
// {likedItems.map((item) => (
//   <li key={item.id}>{item.name}</li>
// ))}
import "./LikePages.css";
import { AiFillLike, AiOutlineLike } from 'react-icons/ai';
function LikePages() {
    const { filterData, handleLike, } = useContext(ABDULAZIZBEK_CONTEXT);
    const likedItems = filterData.filter((item) => item.like);
    return (
        <div className='Tableldiheigu'>
            {likedItems.length > 0 ? (
                <table>
                    <thead>
                        <tr>
                            <th className='JHBHHBH'>Img</th>
                            <th className='JHBHHBH'>Soni</th>
                            <th className='JHBHHBH'>Narx</th>
                            <th className='JHBHHBH'>Xizmat</th>
                        </tr>
                    </thead>
                    <tbody>
                        {likedItems.map((item) => (
                            <tr key={item.id}>
                                <td className='few'><img className='duhewuh' src={item.img} alt="" /></td>
                                <td className='few'><span>{item.soni}</span></td>
                                <td className='few'>{item.narx}</td>
                                <td className='few'>
                                    <p className={item ? "AiFillLike" : "FcLike"} onClick={() => handleLike(item.id)}>
                                        {item.like ? <AiFillLike className='JHBHHBH' /> : <AiOutlineLike  className='JHBHHBH' />}
                                    </p>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <div style={{ width: "100%", height: "100%", textAlign: "center" }}>
                    <h1 style={{ alignItems: "center", justifyContent: "center" }}>Malumot Yoq Like Bosing</h1>
                </div>
            )}
        </div>
    );
}

export default LikePages;