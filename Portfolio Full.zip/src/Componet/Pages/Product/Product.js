import React, { useContext, useState } from 'react';
import { BsFillBasketFill, } from "react-icons/bs";
import { AiFillLike, AiOutlineLike, AiOutlineSearch } from "react-icons/ai";
import { ABDULAZIZBEK_CONTEXT } from '../../Context/Context';
import { Rating, Stack } from '@mui/material';
import "./Product.css";
import { GoGitCompare } from "react-icons/go";
import { FcLike } from "react-icons/fc";
import { NavLink, useNavigate, useParams } from 'react-router-dom';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
export default function Product() {
  let paramID = useParams()
  let { filterData } = useContext(ABDULAZIZBEK_CONTEXT)
  let p = filterData.filter(i => +i.id === +paramID.id).map(item => item);
  const style = {
    position: 'absolute',
    height: "6100%",
    width: "100%",
    bgcolor: 'background.paper',
    // boxShadow: 24,
    p: 4,
  };
  const amd_AMD = useNavigate()
  const cartPagesContext = () => {
    amd_AMD(`/cart`)
  }
  const { name, cartPlusFunc, cartMinusFunc, handleLike, catas3, catas2, catas1, setName, handleCart, handleDeleteCart, } = useContext(ABDULAZIZBEK_CONTEXT);
  const [producttabs1, setProducttabs1] = useState(1);
  const producttabs1Fuction = (AMDDDD) => {
    setProducttabs1(AMDDDD)
  }
  const [images, setImages] = useState(1);
  const handleImg = (img) => {
    setImages(img)
  }
  const [colorButton, setColorButton] = useState(1);
  const handleColorButton = (colorbutton) => {
    setColorButton(colorbutton)
  }
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <div className='kmewifm'>
      {
        p.length > 0 ? (

          <div className="Salom">
            <Modal
              open={open}
              aria-labelledby="modal-modal-title"
              aria-describedby="modal-modal-description"
            >
              <Box sx={style}>
                <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                  <div className='fejwoij'>
                    <h1 className='ehfwiuhui' onClick={() => handleClose()}>X</h1>
                    {
                      p.map((avars) => {
                        return (
                          <div className='efwjhui'>
                            <div className='uhefiwgu'>
                              <img onClick={() => handleImg(1)} className='dwqjioj' src={avars.img1} alt="" />
                              <img onClick={() => handleImg(2)} className='dwqjioj' src={avars.img2} alt="" />
                              <img onClick={() => handleImg(3)} className='dwqjioj' src={avars.img3} alt="" />
                              <img onClick={() => handleImg(4)} className='dwqjioj' src={avars.img4} alt="" />
                              <img onClick={() => handleImg(5)} className='dwqjioj' src={avars.img5} alt="" />
                            </div>
                            <div className='efwjoi'>
                              <img className={images === 1 ? "djwoiw uyfgewuyfgeu" : "kjehf"} src={avars.img1} alt="" />
                              <img className={images === 2 ? "djwoiw uyfgewuyfgeu" : "kjehf"} src={avars.img2} alt="" />
                              <img className={images === 3 ? "djwoiw uyfgewuyfgeu" : "kjehf"} src={avars.img3} alt="" />
                              <img className={images === 4 ? "djwoiw uyfgewuyfgeu" : "kjehf"} src={avars.img4} alt="" />
                              <img className={images === 5 ? "djwoiw uyfgewuyfgeu" : "kjehf"} src={avars.img5} alt="" />
                            </div>
                          </div>
                        )
                      })
                    }
                    <div className='fewjb'>
                      <button onDoubleClick={() => handleDeleteCart()} className='CardDDS jwhdkjhj'>Add to Cart <BsFillBasketFill /></button>
                      <button className='Compare fewofefuhu'>Compare <GoGitCompare className='GoGitCompare' /></button>
                      <button className='Wishlist dejnhuyg'>Wishlist <FcLike className='FcLike' /></button>
                    </div>
                  </div>
                </Typography>
              </Box>
            </Modal>
            {p.map((ava) => {
              return (
                <div className='CArd' key={ava.id}>
                  <div className='CArd1'>
                    <div>
                      <AiOutlineSearch onClick={handleOpen} className='efhwuhui' />
                      <div className='efwjoi'>
                        <div className={images === 1 ? "djwoiw" : "kjehf"}>
                          <img className='CardRasmKatta' src={ava.img1} alt="" />
                        </div>
                        <div className={images === 2 ? "djwoiw" : "kjehf"}>
                          <img className='CardRasmKatta' src={ava.img2} alt="" />
                        </div>
                        <div className={images === 3 ? "djwoiw" : "kjehf"}>
                          <img className='CardRasmKatta' src={ava.img3} alt="" />
                        </div>
                        <div className={images === 4 ? "djwoiw" : "kjehf"}>
                          <img className='CardRasmKatta' src={ava.img4} alt="" />
                        </div>
                        <div className={images === 5 ? "djwoiw" : "kjehf"}>
                          <img className='CardRasmKatta' src={ava.img5} alt="" />
                        </div>
                      </div>
                      <div className='wdjquydgqu'>
                        <img onClick={() => handleImg(1)} className='dwqjioj' src={ava.img1} alt="" />
                        <img onClick={() => handleImg(2)} className='dwqjioj' src={ava.img2} alt="" />
                        <img onClick={() => handleImg(3)} className='dwqjioj' src={ava.img3} alt="" />
                        <img onClick={() => handleImg(4)} className='dwqjioj' src={ava.img4} alt="" />
                        <img onClick={() => handleImg(5)} className='dwqjioj' src={ava.img5} alt="" />
                      </div>
                    </div>
                  </div>
                  <div className='CArd2'>
                    <p className='catagory1Text'>{ava.catagory1}</p>
                    <div className='nameTextDiv'>
                      <h4 className='nameText'>{ava.name}</h4>
                    </div>
                    <div className='YulduzChaDiv'>
                      <Stack className='YulduzCha' spacing={1}><Rating name="half-rating" className='efwnwey' defaultValue={4.2} precision={0.1} /></Stack>
                    </div>
                    <div className='TextlarLoremDiv'>
                      <div className='TextlarLoremDivDiv1'>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>
                      </div>
                      <div className='TextlarLoremDivDiv2'>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae</p>
                      </div>
                      <div className='TextlarLoremDivDiv3'>
                        <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem</p>
                      </div>
                    </div>
                    <div className='SkuTextDiv'><p className='SkuTextDivP'>SKU:</p> <span className='SkuTextDivSpan'>...</span></div>
                    <div className='BrandTextDivImageDiv'>
                      <h3 className='BrandTextDivImageDivH3'>Brand</h3>
                      <h1 className='BrandTextDivImageDivH1'>IMADE</h1>
                    </div>
                    <div className='ButtonColorSDiv'>
                      <div className='ekefhwiu'>
                        <h3 className='ColorText'>Colour <div className='dwewji'>
                          <button className={colorButton === 1 ? "Button1" : "hufgweug"}></button>
                          <button className={colorButton === 2 ? "Button2" : "hufgweug"}></button>
                          <button className={colorButton === 3 ? "Button3" : "hufgweug"}></button>
                          <button className={colorButton === 4 ? "Button4" : "hufgweug"}></button>
                          <button className={colorButton === 5 ? "Button5" : "hufgweug"}></button>
                          <button className={colorButton === 6 ? "Button6" : "hufgweug"}></button>
                          <button className={colorButton === 7 ? "Button7" : "hufgweug"}></button>
                          <button className={colorButton === 8 ? "Button8" : "hufgweug"}></button>
                          <button className={colorButton === 9 ? "ButtoN9" : "hufgweug"}></button>
                          <button className={colorButton === 10 ? "ButtoN10" : "hufgweug"}></button>
                        </div></h3>
                      </div>
                      <div className='Button_S_Div'>
                        <button onClick={() => handleColorButton(1)} className={`Button1`}></button>
                        <button onClick={() => handleColorButton(2)} className={`Button2`}></button>
                        <button onClick={() => handleColorButton(3)} className={`Button3`}></button>
                        <button onClick={() => handleColorButton(4)} className={`Button4`}></button>
                        <button onClick={() => handleColorButton(5)} className={`Button5`}></button>
                        <button onClick={() => handleColorButton(6)} className={`Button6`}></button>
                        <button onClick={() => handleColorButton(7)} className={`Button7`}></button>
                        <button onClick={() => handleColorButton(8)} className={`Button8`}></button>
                        <button onClick={() => handleColorButton(9)} className={`Button9`}></button>
                        <button onClick={() => handleColorButton(10)} className={`Button10`}></button>
                      </div>
                    </div>
                  </div>
                  <div className='CArd3'>
                    <div className='CarD3Div1'>
                      <p>Delivery:</p>
                      <div>
                        <span>Free</span>
                      </div>
                    </div>
                    <div className='CarD3Div2'>
                      <p>Stock:</p>
                      <div>
                        <span>26</span>
                      </div>
                    </div>
                    <div className='LineProductTotal_top'></div>
                    <div className='ButtonSdiv'>
                      <button className='Compare'>Compare <GoGitCompare className='GoGitCompare' /></button>
                      <button onClick={() => handleLike(ava.id)} className='Wishlist'>Wishlist <p className={ava ? "AiFillLike" : "FcLike"} onClick={() => handleLike(ava.id)}>
                                          {ava.like ? <AiFillLike /> : <AiOutlineLike />}
                                        </p></button>
                    </div>
                    <div className='AMMAA2'>
                      <h1>${ava.narx}</h1>
                    </div>
                    <div className='ButtonSDiv'>
                      <button onClick={() => cartMinusFunc(ava.id)} className='ButtonSDivButton1'>-</button>
                      <h1 className='ButtonSDivH1'>{ava.soni}</h1>
                      <button onClick={() => cartPlusFunc(ava.id)} className='ButtonSDivButton2'>+</button>
                    </div>
                    <button onClick={() => handleCart(ava)} className='CardDDS'>Add to Cart <BsFillBasketFill /></button>
                  </div>
                </div>
              )
            })}
            <div className='AUHS'>
              <div className="dwuyg">
                <h1>Bundles <span>(4)</span></h1>
                <div className='ejwoihoew'>
                  <div className='dneo'>
                    {p.map((ass) => {
                      return (
                        <div className='Diccihsud'>
                          <img src={ass.img} alt="" />
                          <div>
                            <p>{ass.catagory1}</p>
                            <div>
                              <span>{ass.name}</span>
                            </div>
                            <h4>{ass.narx}</h4>
                          </div>
                        </div>
                      )
                    })}
                    <h1 className='Pluwussugwd cweuhe'>+</h1>
                    <div className='dneo dnnewniu'>
                      {p.map((ass) => {
                        return (
                          <div className='Diccihsud ifwbu'>
                            <img src={ass.img} alt="" />
                            <div>
                              <p>{ass.catagory1}</p>
                              <div>
                                <span>{ass.name}</span>
                              </div>
                              <h4>{ass.narx}</h4>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                    <h1 className='Pluwussugwd fmwenfinwun'>=</h1>
                    <div className='ehiuwe'>
                      <h1>{ }</h1>
                      <button className='CardDDS fewfioheu uwyguyf'>Add to Cart <BsFillBasketFill /></button>
                    </div>
                  </div>
                  <div>
                  </div>
                </div>
              </div>
            </div>
            <div className='emfkwenfn'>
              <div>
                <div className='hwuef'>
                  <h1 className='fwjnjfbwj' onClick={() => producttabs1Fuction(1)}>Description</h1>
                  <h1 className='fwjnjfbwj' onClick={() => producttabs1Fuction(2)}>Specifications</h1>
                  <h1 className='fwjnjfbwj' onClick={() => producttabs1Fuction(3)}>Reviews</h1>
                </div>
                <div>
                  <div className={producttabs1 === 1 ? "Index1" : "none"}>
                    <div className='fkewnfk cwehuy'>
                      <h4>Lorem ipsum</h4>
                      <p className='cwehuy'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    </div>
                    <div className='fkewnfk'>
                      <h4>Sed ut perspiciatis</h4>
                      <p>Omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
                    </div>
                    <div className='fkewnfk'>
                      <h4>Neque porro quisquam</h4>
                      <p>Est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.</p>
                    </div>
                  </div>
                  <div className={producttabs1 === 2 ? "Index1" : "none"}>
                    <h1>
                      <div className='fkewnfk cwehuy'>
                        <h4>Lorem ipsum</h4>
                        <p className='cwehuy'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                      </div>
                    </h1>
                  </div>
                  <div className={producttabs1 === 3 ? "Index1" : "none"}>
                    <h1>
                      <div className='fkewnfk'>
                        <h4>Neque porro quisquam</h4>
                        <p>Est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.</p>
                      </div>
                    </h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div><h1>Malumot Yoq 😂</h1>
            <NavLink to={"/shop"}>Shopga qaytish</NavLink>
          </div>
        )
      }
    </div >
  )
}