import React, { useContext } from 'react';
import { ABDULAZIZBEK_CONTEXT } from '../../Context/Context';
import { NavLink } from 'react-router-dom';
import "./Card.css";
function Cart() {
    const { cart, handleDeleteCart } = useContext(ABDULAZIZBEK_CONTEXT);
    return (
        <div>
            {cart.length > 0 ? (
                <div className='Tableldiheigu'>
                    <table>
                        <thead>
                            <tr>
                                <td>img</td>
                                <td>name</td>
                                <td>narx</td>
                                <td>rangi</td>
                                <td>soni</td>
                                <td>Xizmat</td>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                cart.map((amd) => {
                                    return (
                                        <tr>
                                            <td>
                                                <img src={amd.img} alt="" />
                                            </td>
                                            <td>
                                                {amd.name}
                                            </td>
                                            <td>
                                                {amd.narx}
                                            </td>
                                            <td>
                                                {amd.rangi}
                                            </td>
                                            <td>
                                                {amd.soni}
                                            </td>
                                            <td>
                                                <button className='AAMAMS' onClick={() => handleDeleteCart(amd.id)}>Delete</button>
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>
            )
                : (
                    <div style={{ paddingTop: "300px" }}>
                        <NavLink to={"/shop"}>Shopga Qaytish</NavLink>
                    </div>
                )
            }
        </div>
    )
}
export default Cart;