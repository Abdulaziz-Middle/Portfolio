import { useContext } from 'react';
import React from "react";
import "./Home.css";
import { CarouselProvider, Slider, Slide, ButtonNext, ButtonBack } from 'pure-react-carousel';
import 'pure-react-carousel/dist/react-carousel.es.css';
import Rasm1 from "./Assets/2651123814 1.png";
import Rasm2 from "./Assets/ds4_controller 1.svg";
import Rasm3 from "./Assets/iph 1.svg";
import Xizmatlar1 from "./Assets/Xizmatlar/Icons.png";
import Xizmatlar2 from "./Assets/Xizmatlar/Icons (1).png";
import Xizmatlar3 from "./Assets/Xizmatlar/Icons (3).png";
import Xizmatlar4 from "./Assets/Xizmatlar/Icons (4).png";
import Xizmatlar5 from "./Assets/Xizmatlar/Icons (5).png";
import { ABDULAZIZBEK_CONTEXT } from '../../Context/Context';
import "slick-carousel/slick/slick.css";
import { AiFillLike, AiOutlineLike } from "react-icons/ai";
import "slick-carousel/slick/slick-theme.css";
import { BsFillBasketFill, } from "react-icons/bs";
import { BiSolidHandRight } from "react-icons/bi";
import 'pure-react-carousel/dist/react-carousel.es.css';
import { useNavigate } from 'react-router-dom';
import AA1 from "./Assets/Catagory4/AA1.png";
import AA2 from "./Assets/Catagory4/AA2.png";
function Home() {
  const { shop, filterData,homeDivCatacogory2, setName, handleCart, handleLike } = useContext(ABDULAZIZBEK_CONTEXT);
  var settings = {
  };
  const abdulazizbek = useNavigate();
  function handlePages(value) {
    abdulazizbek(`/product/`)
    setName([value]);
  };
  return (
    <>
      <div className='Home'>
        <div>
          <div>
            <div className='CaruselDiv'>
              <CarouselProvider naturalSlideWidth={100}
                naturalSlideHeight={40} totalSlides={3} className='dwhudygweuy'>
                <Slider>
                  <Slide className='CaruselSliderSlide1' index={0}>
                    <img className='CaruselSliderSlideImg1' src={Rasm3} alt="" />
                    <div className='CaruselSliderSlideDiv1'>
                      <h1 className='CaruselSliderSlideDiv1H1'>NEW <span className='CaruselSliderSlideDiv1HSPAN'>NAMPHONE</span> RELEASE THIS FALL</h1>
                    </div>
                    <button className='CaruselSliderSlideButton1'>Find Out More</button>
                    <div>
                    </div>
                  </Slide>
                  <Slide className='CaruselSliderSlide2' index={1}>
                    <img src={Rasm2} className='CaruselSliderSlideImg2' alt="" />
                    <div className='CaruselSliderSlideDiv2'>
                      <h1 className='CaruselSliderSlideDiv2H1'><span className='CaruselSliderSlideDiv2H1SPAN'>PLAYBOX</span> CONSOLE X245-HD</h1>
                    </div>
                    <button className='CaruselSliderSlideButton2'>Find Out More</button>
                  </Slide>
                  <Slide className='CaruselSliderSlide3' index={2}>
                    <img src={Rasm1} className='CaruselSliderSlideImg3' alt="" />
                    <div className='CaruselSliderSlideDiv3'>
                      <h1 className='CaruselSliderSlideDiv3H1'>KEEP YOUR SHAPE WITH
                        ALL NEW <span className='CaruselSliderSlideDiv3H1SPAN'>GADGETS</span></h1>
                    </div>
                    <button className='CaruselSliderSlideButton3'>Find Out More</button>
                    <div>
                    </div>
                  </Slide>
                </Slider>
              </CarouselProvider>
              <div className='fewfniuwehfuyw'>
                <div className='Xizmatlar'>
                  <div className='XizmatlarDiv1'>
                    <img className='XizmatlarDiv1Img' src={Xizmatlar1} alt="" />
                    <div className='XizmatlarDiv1Div'>
                      <h5 className='XizmatlarDiv1DivH5'>Guarantee</h5>
                      <p className='XizmatlarDiv1DivP'>24 Months</p>
                    </div>
                  </div>
                  <div className='XizmatlarDiv2'>
                    <img className='XizmatlarDiv2Img' src={Xizmatlar2} alt="" />
                    <div className='XizmatlarDiv2Div'>
                      <h5 className='XizmatlarDiv1DivH5'>Rate Paying</h5>
                      <p className='XizmatlarDiv2DivP'>4 - 12 Months</p>
                    </div>
                  </div>
                  <div className='XizmatlarDiv3'>
                    <img className='XizmatlarDiv3Img' src={Xizmatlar3} alt="" />
                    <div className='XizmatlarDiv3Div'>
                      <h5 className='XizmatlarDiv3DivH5'>Payments</h5>
                      <p className='XizmatlarDiv3DivP'>Secured</p>
                    </div>
                  </div>
                  <div className='XizmatlarDiv4'>
                    <img className='XizmatlarDiv4Img' src={Xizmatlar4} alt="" />
                    <div className='XizmatlarDiv4Div'>
                      <h5 className='XizmatlarDiv4DivH5'>Free Delivery</h5>
                      <p className='XizmatlarDiv4DivP'>from $100</p>
                    </div>
                  </div>
                  <div className='XizmatlarDiv5'>
                    <img className='XizmatlarDiv5Img' src={Xizmatlar5} alt="" />
                    <div className='XizmatlarDiv5Div'>
                      <h5 className='XizmatlarDiv5DivH5'>Brands</h5>
                      <p className='XizmatlarDiv5DivP'>Only Top</p>
                    </div>
                  </div>
                </div>
                <div className='CardS1'>
                  <CarouselProvider totalSlides={3}>
                    <div className='CardS1Div1'>
                      <div className='CardS1Div1Div1'>
                        <h1 className='CardS1Div1Div1H5'>Featured Products</h1>
                        <div className='Line'></div>
                      </div>
                      <div className='CardS1Div1Div2'>
                        <ButtonBack className='ButtonBack'>{"<"}</ButtonBack>
                        <ButtonNext className='ButtonNext'>{">"}</ButtonNext>
                      </div>
                    </div>
                    <Slider className='CardS1Div2' {...settings}>
                      <div className='CardS1Div2Div1'>
                        {
                          filterData.map((home1) => {
                            return (
                              <div key={home1.id} className='CardS1Div2Div1CardS'>
                                <p>{home1.catagory1}</p>
                                <div onClick={() => handlePages(home1)} >
                                  <h4 style={{ cursor: "pointer" }}>{home1.name}</h4>
                                </div>
                                <img src={home1.img} alt="" />
                                <div className='CardS1Div2Div1CardSDiv'>
                                  <span style={{ cursor: "pointer" }} className='CardS1Div2Div1CardSDivSPAN'>{home1.narx}</span>
                                  <div className='dwnquhu'>
                                    <span className={home1 ? "AiFillLike" : "AiOutlineLike"} onClick={() => handleLike(home1.id)}>
                                      {home1.like ? <AiFillLike /> : <AiOutlineLike />}
                                    </span>
                                  </div>
                                  <div className='CardS1Div2Div1CardSDivDivBasket'>
                                    <BsFillBasketFill onClick={() => handleCart(home1)} className='CardS1Div2Div1CardSDivDivBasketIcons' />
                                  </div>
                                </div>
                              </div>
                            )
                          })
                        }
                      </div>
                    </Slider>
                  </CarouselProvider>
                </div>
              </div>
            </div>
          </div>
          <div className='Filter'>
            <div>
              <div className='CardS1Div1Div1'>
                <h1 className='CardS1Div1Div1H5 H33'>Categories</h1>
                <div className='LineA'></div>
              </div>
              <div className='CardS1Div1Div1DIV'>
                {
                  homeDivCatacogory2.map((v) => {
                    return (
                      <div key={v.id} className='Catagory'>
                        <h4 onClick={() => handlePages(v)} className='CatagoryH4'>{v.name}</h4>
                        <img className='CatagoryImg' src={v.img} alt="" />
                        <div className='CatagoryDiv'>
                          <BiSolidHandRight className='CatagoryDivIcons' />
                        </div>
                      </div>
                    )
                  })
                }
              </div>
            </div>
          </div>
          <div>
            <div className='CardS1'>
              <CarouselProvider totalSlides={3}>
                <div className='CardS1Div1'>
                  <div className='CardS1Div1Div1'>
                    <h1 className='CardS1Div1Div1H5'>Bestsellers</h1>
                    <div className='LineB'></div>
                  </div>
                  <div className='CardS1Div1Div2'>
                    <ButtonBack className='ButtonBack'>{"<"}</ButtonBack>
                    <ButtonNext className='ButtonNext'>{">"}</ButtonNext>
                  </div>
                </div>
                <Slider className='CardS1Div2' {...settings}>
                <div className='CardS1Div2Div1'>
                        {
                          filterData.map((home1) => {
                            return (
                              <div key={home1.id} className='CardS1Div2Div1CardS'>
                                <p>{home1.catagory1}</p>
                                <div onClick={() => handlePages(home1)} >
                                  <h4 style={{ cursor: "pointer" }}>{home1.name}</h4>
                                </div>
                                <img src={home1.img} alt="" />
                                <div className='CardS1Div2Div1CardSDiv'>
                                  <span style={{ cursor: "pointer" }} className='CardS1Div2Div1CardSDivSPAN'>{home1.narx}</span>
                                  <div>
                                    <span className={home1 ? "AiFillLike" : "AiOutlineLike"} onClick={() => handleLike(home1.id)}>
                                      {home1.like ? <AiFillLike /> : <AiOutlineLike />}
                                    </span>
                                  </div>
                                  <div className='CardS1Div2Div1CardSDivDivBasket'>
                                    <BsFillBasketFill onClick={() => handleCart(home1)} className='CardS1Div2Div1CardSDivDivBasketIcons' />
                                  </div>
                                </div>
                              </div>
                            )
                          })
                        }
                      </div>
                </Slider>
              </CarouselProvider>
            </div>
          </div>
          <div className='RASMLAR2Taligi'>
            <img className='dnwendi' src={AA1} alt="" />
            <img className='ewjfuy' src={AA2} alt="" />
          </div>
          <div>
            <div className='CardS1'>
              <CarouselProvider totalSlides={3}>
                <div className='CardS1Div1'>
                  <div className='CardS1Div1Div1'>
                    <h1 className='CardS1Div1Div1H5'>Big Deals</h1>
                    <div className='LineV'></div>
                  </div>
                  <div className='CardS1Div1Div2'>
                    <ButtonBack className='ButtonBack'>{"<"}</ButtonBack>
                    <ButtonNext className='ButtonNext'>{">"}</ButtonNext>
                  </div>
                </div>
                <Slider className='CardS1Div2' {...settings}>
                <div className='CardS1Div2Div1'>
                        {
                          filterData.map((home1) => {
                            return (
                              <div key={home1.id} className='CardS1Div2Div1CardS'>
                                <p>{home1.catagory1}</p>
                                <div onClick={() => handlePages(home1)} >
                                  <h4 style={{ cursor: "pointer" }}>{home1.name}</h4>
                                </div>
                                <img src={home1.img} alt="" />
                                <div className='CardS1Div2Div1CardSDiv'>
                                  <span style={{ cursor: "pointer" }} className='CardS1Div2Div1CardSDivSPAN'>{home1.narx}</span>
                                  <div>
                                    <span className={home1 ? "AiFillLike" : "AiOutlineLike"} onClick={() => handleLike(home1.id)}>
                                      {home1.like ? <AiFillLike /> : <AiOutlineLike />}
                                    </span>
                                  </div>
                                  <div className='CardS1Div2Div1CardSDivDivBasket'>
                                    <BsFillBasketFill onClick={() => handleCart(home1)} className='CardS1Div2Div1CardSDivDivBasketIcons' />
                                  </div>
                                </div>
                              </div>
                            )
                          })
                        }
                      </div>
                </Slider>
              </CarouselProvider>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
export default Home;