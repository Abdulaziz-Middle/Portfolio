import React, { useContext } from 'react';
import { FaTelegramPlane } from "react-icons/fa";
import Kartalar from "./Assets/Payment_links.png";
import Logo from "./Assets/Logo.png";
import AB1 from "./Assets/Rasmlar/brands.png";
import AB2 from "./Assets/Rasmlar/brands (1).png";
import AB3 from "./Assets/Rasmlar/brands (2).png";
import AB4 from "./Assets/Rasmlar/brands (3).png";
import AB5 from "./Assets/Rasmlar/brands (4).png";
import AB6 from "./Assets/Rasmlar/brands (5).png";
import AB7 from "./Assets/Rasmlar/brands (6).png";
import AB8 from "./Assets/Rasmlar/brands (7).png";
import AB9 from "./Assets/Rasmlar/brands (8).png";
import AB10 from "./Assets/Rasmlar/brands (9).png";
import { Rating, Stack } from '@mui/material';
import "./Footer.css";
import { ABDULAZIZBEK_CONTEXT } from '../../Context/Context';
import { NavLink } from 'react-router-dom';
import { AiOutlineFacebook, AiFillInstagram, AiFillLinkedin, AiFillTwitterCircle, AiFillYoutube } from "react-icons/ai";
function Footer() {
    const { catas3, catas2, catas1, } = useContext(ABDULAZIZBEK_CONTEXT);
    return (
        <div className='fwelfpowem'>
            <div className='RasmalarDiv'>
                <img className='RasmlarDivImages' src={AB1} alt="" />
                <img className='RasmlarDivImages' src={AB2} alt="" />
                <img className='RasmlarDivImages' src={AB3} alt="" />
                <img className='RasmlarDivImages' src={AB4} alt="" />
                <img className='RasmlarDivImages' src={AB5} alt="" />
                <img className='RasmlarDivImages' src={AB6} alt="" />
                <img className='RasmlarDivImages' src={AB7} alt="" />
                <img className='RasmlarDivImages' src={AB8} alt="" />
                <img className='RasmlarDivImages' src={AB9} alt="" />
                <img className='RasmlarDivImages' src={AB10} alt="" />
            </div>
            <div className='CatasDiv'>
                <div className='CatasDiv1'>
                    <h1 className="H1ALA">Top Rated</h1>
                    <div className="HBHYTDRTDCTRHGTTR"></div>
                    {
                        catas1.map((as1) => {
                            return (
                                <div className='catas1' key={as1.id}>
                                    <img src={as1.img} alt="" />
                                    <div>
                                        <p>{as1.name}</p>
                                        <Stack className='Stack' spacing={1}><Rating name="half-rating" defaultValue={4.2} precision={0.1} /></Stack>
                                        <span>{as1.narx}</span>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
                <div className='CatasDiv2'>
                    <h1 className="H1ALA">Bestsellers</h1>
                    <div className="HBHYTDRTDCTRHGTTR"></div>
                    {
                        catas2.map((as2) => {
                            return (
                                <div className='catas1' key={as2.id}>
                                    <img src={as2.img} alt="" />
                                    <div>
                                        <p>{as2.name}</p>
                                        <Stack className='Stack' spacing={1}><Rating name="half-rating" defaultValue={4.2} precision={0.1} /></Stack>
                                        <span>{as2.narx}</span>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
                <div className='CatasDiv3'>
                    <h1 className="H1ALA">Mega Offers</h1>
                    <div className="HBHYTDRTDCTRHGTTR"></div>
                    {
                        catas3.map((as3) => {
                            return (
                                <div className='catas1' key={as3.id}>
                                    <img src={as3.img} alt="" />
                                    <div>
                                        <p>{as3.name}</p>
                                        <Stack className='Stack' spacing={1}><Rating name="half-rating" defaultValue={4.2} precision={0.1} /></Stack>
                                        <a className='AAAHAH'>{as3.narx}</a>
                                        <p><del className='Del A'>{as3.eski}</del></p>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
            <div className='Telegram'>
                <p>Subscribe to Our Newsletter  -  get a $20 Coupon for your first order! </p>
                <input className='input' type="email" placeholder='Enter your email address' />
                <NavLink className="AAA" to={"https://t.me/AMD_amd_AMD_amd_AMD"}>
                    <div className='TelegramPlane'>
                        <FaTelegramPlane className='AMAMDALSLA' />
                    </div>
                </NavLink>
                <div>
                </div>
            </div>
            <div className='KMKOWMDNEIFNEIU'>
                <div className='CARASASAFE1'>
                    <img className='LogoKWDMWK' src={Logo} alt="" />
                    <div>
                        <div className='ADLLA'>
                            <p className='efpeof'>Headquarters</p>
                            <span className='femkef'>AbdulazizbekMiddleProgrammer</span>
                        </div>
                        <div className='ADLLA'>
                            <p className='efpeof'>Email</p>
                            <span className='femkef'>abdulazizbekmiddledasturchi@gmail.com</span>
                        </div>
                        <div className='ADLLA'>
                            <p className='efpeof'>Telephone</p>
                            <span className='femkef'>+998_91_760_17_79</span>
                        </div>
                        <div className='efpoekpofek'>
                            <AiOutlineFacebook />
                            <AiFillInstagram />
                            <AiFillLinkedin />
                            <AiFillTwitterCircle />
                            <AiFillYoutube />
                        </div>
                    </div>
                </div>
                <div className='CARASASAFE'>
                    <p className='fejkne'>Categories</p>
                    <p className='efkjnekje'>TV & Audio</p>
                    <p className='efkjnekje'>Smartphones</p>
                    <p className='efkjnekje'>Laptops & PCs</p>
                    <p className='efkjnekje'>Gadgets</p>
                    <p className='efkjnekje'>Photo & Video</p>
                    <p className='efkjnekje'>Gifts</p>
                    <p className='efkjnekje'>Books</p>
                    <p className='efkjnekje'>Toys</p>
                </div>
                <div className='CARASASAFE'>
                    <p className='fejkne'>Useful Links</p>
                    <p className='efkjnekje'>About</p>
                    <p className='efkjnekje'>Contact</p>
                    <p className='efkjnekje'>Wishlist</p>
                    <p className='efkjnekje'>Compare</p>
                    <p className='efkjnekje'>FAQ</p>
                    <p className='efkjnekje'>Terms & Conditions</p>
                    <p className='efkjnekje'>Privacy Policy</p>
                    <p className='efkjnekje'>Cookie Policy</p>
                </div>
                <div className='CARASASAFE'>
                    <p className='fejkne'>Customer Service</p>
                    <p className='efkjnekje'>My Account</p>
                    <p className='efkjnekje'>My Cart</p>
                    <p className='efkjnekje'>Track Order</p>
                    <p className='efkjnekje'>Returns & Exchanges</p>
                    <p className='efkjnekje'>Repair Services</p>
                    <p className='efkjnekje'>Support</p>
                </div>
            </div>
            <div className='©🄱🄾🅈🄳🄾🅀_🄾🄺🄴🄽🄴'>
                <p>©🄱🄾🅈🄳🄾🅀_🄾🄺🄴🄽🄴 Tomonidan ishlab chiqarilgan</p>
                <img src={Kartalar} alt="" />
            </div>
        </div>
    )
}
export default Footer;