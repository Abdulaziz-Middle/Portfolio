import React, { createContext, useState } from 'react';
import A1 from "../Pages/Home/Assets/Catagory2/A1.png";
import A2 from "../Pages/Home/Assets/Catagory2/A2.png";
import A3 from "../Pages/Home/Assets/Catagory2/A3.png";
import A4 from "../Pages/Home/Assets/Catagory2/A4.png";
import A5 from "../Pages/Home/Assets/Catagory2/A5.png";
import A6 from "../Pages/Home/Assets/Catagory2/A6.png";
import A7 from "../Pages/Home/Assets/Catagory2/A7.png";
import A8 from "../Pages/Home/Assets/Catagory2/A8.png";
import as1 from "../Pages/Home/Assets/Catagory6/1.png";
import as2 from "../Pages/Home/Assets/Catagory6/2.png";
import as3 from "../Pages/Home/Assets/Catagory6/3.png";
import as4 from "../Pages/Home/Assets/Catagory6/4.png";
import as5 from "../Pages/Home/Assets/Catagory6/5.png";
import as6 from "../Pages/Home/Assets/Catagory6/6.png";
import as7 from "../Pages/Home/Assets/Catagory6/7.png";
import as8 from "../Pages/Home/Assets/Catagory6/8.png";
import as9 from "../Pages/Home/Assets/Catagory6/9.png";
import ShopHome1Home1 from "../Pages/Shop/Assets/Home1/1.png";
import ShopHome1Home2 from "../Pages/Shop/Assets/Home1/2.png";
import ShopHome1Home3 from "../Pages/Shop/Assets/Home1/3.png";
import ShopHome1Home4 from "../Pages/Shop/Assets/Home1/4.png";
import ShopHome1Home5 from "../Pages/Shop/Assets/Home1/5.png";
import ShopHome1Home6 from "../Pages/Shop/Assets/Home1/6.png";
import ShopHome1Home7 from "../Pages/Shop/Assets/Home1/7.png";
import ShopHome1Home8 from "../Pages/Shop/Assets/Home1/8.png";
import ShopHome1Home9 from "../Pages/Shop/Assets/Home1/9.png";
import ShopHome1Home10 from "../Pages/Shop/Assets/Home1/10.png";
import ShopHome1Home11 from "../Pages/Shop/Assets/Home1/11.png";
import ShopHome1Home12 from "../Pages/Shop/Assets/Home1/12.png";
import ShopHome1Home13 from "../Pages/Shop/Assets/Home1/13.png";
import ShopHome1Home14 from "../Pages/Shop/Assets/Home1/14.png";
import ShopHome1Home15 from "../Pages/Shop/Assets/Home1/15.png";
import ShopHome1Home16 from "../Pages/Shop/Assets/Home1/16.png";
import ShopHome1Home17 from "../Pages/Shop/Assets/Home1/17.png";
import ShopHome1Home18 from "../Pages/Shop/Assets/Home1/18.png";
import ShopHome1Home19 from "../Pages/Shop/Assets/Home1/19.png";
import ShopHome1Home20 from "../Pages/Shop/Assets/Home1/20.png";
// Product 
import ProductsCard1Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card1/1.png";
import ProductsCard1Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card1/2.png";
import ProductsCard1Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card1/3.png";
import ProductsCard1Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card1/4.png";
import ProductsCard1Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card1/5.png";
import ProductsCard2Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card2/1.jpg";
import ProductsCard2Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card2/2.jpg";
import ProductsCard2Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card2/3.jpg";
import ProductsCard2Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card2/4.jpg";
import ProductsCard2Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card2/5.jpg";
import ProductsCard3Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card3/1.jpg";
import ProductsCard3Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card3/2.jpg";
import ProductsCard3Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card3/3.jpg";
import ProductsCard3Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card3/4.jpg";
import ProductsCard3Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card3/5.jpg";
import ProductsCard4Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card4/1.jpg";
import ProductsCard4Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card4/2.jpg";
import ProductsCard4Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card4/3.jpg";
import ProductsCard4Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card4/4.jpg";
import ProductsCard4Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card4/5.jpg";
import ProductsCard5Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card5/1.jpg";
import ProductsCard5Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card5/2.jpg";
import ProductsCard5Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card5/3.jpg";
import ProductsCard5Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card5/4.jpg";
import ProductsCard5Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card5/5.jpg";
import ProductsCard6Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card6/1.jpg";
import ProductsCard6Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card6/2.jpg";
import ProductsCard6Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card6/3.png";
import ProductsCard6Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card6/4.png";
import ProductsCard6Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card6/5.jpg";
import ProductsCard7Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card7/1.jpg";
import ProductsCard7Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card7/2.jpg";
import ProductsCard7Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card7/3.jpg";
import ProductsCard7Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card7/4.jpg";
import ProductsCard7Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card7/5.jpg";
import ProductsCard8Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card8/1.jpg";
import ProductsCard8Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card8/2.jpg";
import ProductsCard8Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card8/3.jpg";
import ProductsCard8Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card8/4.jpg";
import ProductsCard8Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card8/5.jpg";
import ProductsCard9Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card9/1.jpg";
import ProductsCard9Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card9/2.jpg";
import ProductsCard9Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card9/3.jpg";
import ProductsCard9Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card9/4.jpg";
import ProductsCard9Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card9/5.jpg";
import ProductsCard10Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card10/1.jpg";
import ProductsCard10Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card10/2.jpg";
import ProductsCard10Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card10/3.jpg";
import ProductsCard10Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card10/4.jpg";
import ProductsCard10Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card10/5.jpg";
import ProductsCard11Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card11/1.jpg";
import ProductsCard11Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card11/2.jpg";
import ProductsCard11Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card11/3.jpg";
import ProductsCard11Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card11/4.jpg";
import ProductsCard11Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card11/5.jpg";
import ProductsCard12Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card12/1.jpg";
import ProductsCard12Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card12/2.jpg";
import ProductsCard12Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card12/3.jpg";
import ProductsCard12Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card12/4.jpg";
import ProductsCard12Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card12/5.jpg";
import ProductsCard13Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card13/1.jpg";
import ProductsCard13Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card13/2.jpg";
import ProductsCard13Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card13/3.jpg";
import ProductsCard13Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card13/4.jpg";
import ProductsCard13Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card13/5.jpg";
import ProductsCard14Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card14/1.jpg";
import ProductsCard14Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card14/2.jpg";
import ProductsCard14Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card14/3.jpg";
import ProductsCard14Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card14/4.jpg";
import ProductsCard14Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card14/5.jpg";
import ProductsCard16Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card16/1.jpg";
import ProductsCard16Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card16/2.jpg";
import ProductsCard16Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card16/3.jpg";
import ProductsCard16Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card16/4.jpg";
import ProductsCard16Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card16/5.jpg";
import ProductsCard17Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card17/1.jpg";
import ProductsCard17Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card17/2.jpg";
import ProductsCard17Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card17/3.jpg";
import ProductsCard17Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card17/4.jpg";
import ProductsCard17Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card17/5.jpg";
import ProductsCard18Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card18/1.jpg";
import ProductsCard18Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card18/2.jpg";
import ProductsCard18Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card18/3.jpg";
import ProductsCard18Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card18/4.jpg";
import ProductsCard18Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card18/5.jpg";
import ProductsCard19Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card19/1.jpg";
import ProductsCard19Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card19/2.jpg";
import ProductsCard19Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card19/3.jpg";
import ProductsCard19Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card19/4.jpg";
import ProductsCard19Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card19/5.jpg";
import ProductsCard20Rasm1 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card20/1.jpg";
import ProductsCard20Rasm2 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card20/2.jpg";
import ProductsCard20Rasm3 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card20/3.jpg";
import ProductsCard20Rasm4 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card20/4.jpg";
import ProductsCard20Rasm5 from "../Pages/Shop/Assets/CatagoryRasmlarProductdaImageslar/Card20/5.jpg";
import Swal from 'sweetalert2';
export const ABDULAZIZBEK_CONTEXT = createContext();
function Context({ children }) {
  const [search, setSearch] = useState("");
  // console.log(search);
  const [homeDivCatacogory2] = useState([
    {
      id: 1,
      img: A1,
      catagory2: 'TV & Audio',
      name: "TV & Audio",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 2,
      img: A2,
      catagory2: 'Smartphones',
      name: "Smartphones",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 3,
      img: A3,
      catagory2: 'Laptops & PCs',
      name: "Laptops & PCs",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 4,
      img: A4,
      catagory2: 'Gadgets',
      name: "Gadgets",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 5,
      img: A5,
      catagory2: 'Photo & Video',
      name: "Photo & Video",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 6,
      img: A6,
      catagory2: 'Gifts',
      name: "Gifts",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 7,
      img: A7,
      catagory2: 'Books',
      name: "Books",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 8,
      img: A8,
      catagory2: 'Toys',
      name: "Toys",
      soni: 1,
      rangi: "qora"
    },
  ])
  const [catas1] = useState([
    {
      id: 1,
      img: as1,
      name: "PC DELL Vostro 3910 MT, (Intel® Core™ i5-12400)",
      yulduz: `{<Stack spacing={1}><Rating name="half-rating" defaultValue={5} precision={0.1} /></Stack>}`,
      catagory1: "Laptops & PCs",
      narx: "600.00",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 2,
      img: as2,
      name: "Laptop 2in1 Asus VivoBook S 14 Flip TP3402ZA Intel® Core™",
      yulduz: `{<Stack spacing={1}><Rating name="half-rating" defaultValue={5} precision={0.1} /></Stack>}`,
      catagory1: "Laptops & PCs",
      narx: "100.00",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 3,
      img: as3,
      name: "Sony SRS-XP700, MEGA BASS, Bluetooth, LDAC, Wireless, IPX4",
      yulduz: `{<Stack spacing={1}><Rating name="half-rating" defaultValue={5} precision={0.1} /></Stack>}`,
      catagory1: "Laptops & PCs",
      narx: "600.00",
      soni: 1,
      rangi: "qora"
    }
  ])
  const [catas2] = useState([
    {
      id: 1,
      img: as4,
      name: "Panasonic SC-TMAX10E-K, Bluetooth, 300W, AIRQUAKE ",
      catagory1: "TV & Audio",
      narx: "240.00",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 2,
      img: as5,
      name: "Sony Handycam FDR-AX700, 4K HDR(HLG), Black",
      catagory1: "TV & Audio",
      narx: "20.00",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 3,
      img: as6,
      name: "Samsung Galaxy S22,Exynos 2200 Octa-Core",
      catagory1: "TV & Audio",
      narx: "640.00",
      soni: 1,
      rangi: "qora"
    }
  ])
  const [catas3] = useState([
    {
      id: 1,
      img: as7,
      name: "All In One PC ASUS, Intel® Core™ i5-11500B",
      catagory1: "",
      narx: "100.00",
      eski: "100.00",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 2,
      img: as8,
      name: "GoPro HERO10, Filmare 5.3K 30fps, 23MP, Waterproof, GPS",
      catagory1: "",
      narx: "500.00",
      eski: "600.00",
      soni: 1,
      rangi: "qora"
    },
    {
      id: 3,
      img: as9,
      name: "Smartwatch iHunt Watch 6 Titan, Display Full Touch 1.28",
      catagory1: "",
      narx: "250.00",
      eski: "290.00",
      soni: 1,
      rangi: "qora"
    }
  ])
  const [shop, setShop] = useState([
    {
      id: 40,
      catagory1: "Smartphones",
      name: "Apple iPhone 14 Pro, LTPO Super Retina XDR OLED 6.1",
      like: false,
      img: ShopHome1Home1,
      narx: "200.00",
      soni: 1,
      rangi: "000000",
      img1: ProductsCard1Rasm1,
      img2: ProductsCard1Rasm2,
      img3: ProductsCard1Rasm3,
      img4: ProductsCard1Rasm4,
      img5: ProductsCard1Rasm5,
      brand: 'apple',
      priceee: "2-3",
      Yulduzcha: '⭐️⭐️⭐️⭐️⭐️',
      nnnnnaka: "apple",
    },
    {
      id: 41,
      catagory1: "Smartphones",
      name: "Mobile Phone Nokia 8210, Dual SIM, 4G",
      like: false,
      img: ShopHome1Home2,
      narx: "340.00",
      soni: 1,
      rangi: "FFFFFF",
      img1: ProductsCard2Rasm1,
      img2: ProductsCard2Rasm2,
      img3: ProductsCard2Rasm3,
      img4: ProductsCard2Rasm4,
      img5: ProductsCard2Rasm5,
      brand: 'nokia',
      priceee: "3-4",
      Yulduzcha: '⭐️⭐️⭐️',
      nnnnnaka: "nokia"
    },
    {
      id: 42,
      catagory1: "TV & Audio",
      name: "SONY SRSXV900, Wireless Party Speaker, MEGA BASS",
      like: false,
      img: ShopHome1Home3,
      narx: "200.00",
      soni: 1,
      rangi: "319DFF",
      img1: ProductsCard3Rasm1,
      img2: ProductsCard3Rasm2,
      img3: ProductsCard3Rasm3,
      img4: ProductsCard3Rasm4,
      img5: ProductsCard3Rasm5,
      brand: 'lg',
      priceee: "2-3",
      Yulduzcha: '⭐️⭐️⭐️⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 43,
      catagory1: "TV & Audio",
      name: "Headphones, Noise cancelling, Bluetooth 5.0",
      like: false,
      img: ShopHome1Home4,
      narx: "490.00",
      soni: 1,
      rangi: "FFDE31",
      img1: ProductsCard4Rasm1,
      img2: ProductsCard4Rasm2,
      img3: ProductsCard4Rasm3,
      img4: ProductsCard4Rasm4,
      img5: ProductsCard4Rasm5,
      brand: 'samsung',
      priceee: "5+",
      Yulduzcha: '⭐️',
      nnnnnaka: "samsung"
    },
    {
      id: 44,
      catagory1: "Photo & Video",
      name: "D-SLR Canon EOS R10, 4k, DIGIC X, RF-S 18-45mm",
      like: false,
      img: ShopHome1Home5,
      narx: "100.00",
      soni: 1,
      rangi: "FF316A",
      img1: ProductsCard5Rasm1,
      img2: ProductsCard5Rasm2,
      img3: ProductsCard5Rasm3,
      img4: ProductsCard5Rasm4,
      img5: ProductsCard5Rasm5,
      brand: 'lg',
      priceee: "1-2",
      Yulduzcha: '⭐️⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 45,
      catagory1: "Laptops & PCs",
      name: "PC DELL Vostro 3910 MT, (Intel® Core™ i5-12400)",
      like: false,
      img: ShopHome1Home6,
      narx: "500.00",
      soni: 1,
      rangi: "0DA678",
      img1: ProductsCard16Rasm1,
      img2: ProductsCard16Rasm2,
      img3: ProductsCard16Rasm3,
      img4: ProductsCard16Rasm4,
      img5: ProductsCard16Rasm5,
      brand: 'samsung',
      priceee: "5+",
      Yulduzcha: '⭐️⭐️⭐️⭐️',
      nnnnnaka: "samsung"
    },
    {
      id: 46,
      catagory1: "Laptops & PCs",
      name: "Laptop 2in1 Asus VivoBook S 14 Flip TP3402ZA Intel® Core™",
      like: false,
      img: ShopHome1Home7,
      narx: "100.00",
      soni: 1,
      rangi: "9E13F3",
      img1: ProductsCard17Rasm1,
      img2: ProductsCard17Rasm2,
      img3: ProductsCard17Rasm3,
      img4: ProductsCard17Rasm4,
      img5: ProductsCard17Rasm5,
      brand: 'lg',
      priceee: "1-2",
      Yulduzcha: '⭐️⭐️⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 47,
      catagory1: "TV & Audio",
      name: "Sony SRS-XP700, MEGA BASS, Bluetooth, LDAC, Wireless, IPX4",
      like: false,
      img: ShopHome1Home8,
      narx: "400.00",
      soni: 1,
      rangi: "FFAA04",
      img1: ProductsCard3Rasm1,
      img2: ProductsCard3Rasm2,
      img3: ProductsCard3Rasm3,
      img4: ProductsCard3Rasm4,
      img5: ProductsCard3Rasm5,
      brand: 'lenovo',
      priceee: "5+",
      Yulduzcha: '⭐️',
      nnnnnaka: "lenovo"
    },
    {
      id: 48,
      catagory1: "Laptops & PCs",
      name: "Laptop HP 250 G9, Procesor Intel® Core™ i5-1235U",
      like: false,
      img: ShopHome1Home9,
      narx: "400.00",
      soni: 1,
      rangi: "FF64DD",
      img1: ProductsCard6Rasm1,
      img2: ProductsCard6Rasm2,
      img3: ProductsCard6Rasm3,
      img4: ProductsCard6Rasm4,
      img5: ProductsCard6Rasm5,
      brand: 'lg',
      priceee: "4-5",
      Yulduzcha: '⭐️⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 49,
      catagory1: "Photo & Video",
      name: "Canon EF-S 18-135mm f/3.5-5.6 IS USM Nano",
      like: false,
      img: ShopHome1Home10,
      narx: "410.00",
      soni: 1,
      rangi: "17D1DD",
      img1: ProductsCard7Rasm1,
      img2: ProductsCard7Rasm2,
      img3: ProductsCard7Rasm3,
      img4: ProductsCard7Rasm4,
      img5: ProductsCard7Rasm5,
      brand: 'lg',
      priceee: "5+",
      Yulduzcha: '⭐️⭐️⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 50,
      catagory1: "TV & Audio",
      name: "IPS LED Lenovo ThinkVision 27 T27i-10, Full HD (1920 x 1080)",
      like: false,
      img: ShopHome1Home11,
      narx: "180.00",
      soni: 1,
      rangi: "FFDE31",
      img1: ProductsCard8Rasm1,
      img2: ProductsCard8Rasm2,
      img3: ProductsCard8Rasm3,
      img4: ProductsCard8Rasm4,
      img5: ProductsCard8Rasm5,
      brand: 'samsung',
      priceee: "1-2",
      Yulduzcha: '⭐️⭐️⭐️⭐️⭐️',
      nnnnnaka: "samsung"
    },
    {
      id: 51,
      catagory1: "Gadgets",
      name: "Smartwatch Huawei Watch GT 3, Display AMOLED 1.32",
      like: false,
      img: ShopHome1Home12,
      narx: "250.00",
      soni: 1,
      rangi: "000000",
      img1: ProductsCard9Rasm1,
      img2: ProductsCard9Rasm2,
      img3: ProductsCard9Rasm3,
      img4: ProductsCard9Rasm4,
      img5: ProductsCard9Rasm5,
      brand: 'lg',
      priceee: "2-3",
      Yulduzcha: '⭐️⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 52,
      catagory1: "Smartphones",
      name: "Nokia 105 (2019), Dual Sim (Black)",
      like: false,
      img: ShopHome1Home13,
      narx: "20.00",
      soni: 1,
      rangi: "FFFFFF",
      img1: ProductsCard10Rasm1,
      img2: ProductsCard10Rasm2,
      img3: ProductsCard10Rasm3,
      img4: ProductsCard10Rasm4,
      img5: ProductsCard10Rasm5,
      brand: 'lg',
      priceee: "0-5",
      Yulduzcha: '⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 53,
      catagory1: "TV & Audio",
      name: "Panasonic SC-TMAX10E-K, Bluetooth, 300W, AIRQUAKE ",
      like: false,
      img: ShopHome1Home14,
      narx: "240.00",
      soni: 1,
      rangi: "319DFF",
      img1: ProductsCard18Rasm1,
      img2: ProductsCard18Rasm2,
      img3: ProductsCard18Rasm3,
      img4: ProductsCard18Rasm4,
      img5: ProductsCard18Rasm5,
      brand: 'lenovo',
      priceee: "2-3",
      Yulduzcha: '⭐️⭐️⭐️',
      nnnnnaka: "lenono"
    },
    {
      id: 54,
      catagory1: "Photo & Video",
      name: "Sony Handycam FDR-AX700, 4K HDR(HLG), Black",
      like: false,
      img: ShopHome1Home15,
      narx: "200.00",
      soni: 1,
      rangi: "FFDE31",
      img1: ProductsCard19Rasm1,
      img2: ProductsCard19Rasm2,
      img3: ProductsCard19Rasm3,
      img4: ProductsCard19Rasm4,
      img5: ProductsCard19Rasm5,
      brand: 'lg',
      priceee: "2-3",
      Yulduzcha: '⭐️⭐️⭐️⭐️',
      nnnnnaka: "lg"
    },
    {
      id: 55,
      catagory1: "Smartphones",
      name: "Samsung Galaxy S22,Exynos 2200 Octa-Core",
      like: false,
      img: ShopHome1Home16,
      narx: "490.00",
      soni: 1,
      rangi: "0DA678",
      img1: ProductsCard20Rasm1,
      img2: ProductsCard20Rasm2,
      img3: ProductsCard20Rasm3,
      img4: ProductsCard20Rasm4,
      img5: ProductsCard20Rasm5,
      brand: 'samsung',
      priceee: "5+",
      Yulduzcha: '⭐️⭐️',
      nnnnnaka: "samsung"
    },
    {
      id: 56,
      catagory1: "Laptops & PCs",
      name: "E-ink Kindle PaperWhite 2021, 6.8, Waterproof, 8GB, Wi-Fi",
      like: false,
      img: ShopHome1Home17,
      narx: "120.00",
      eski: "160.00",
      soni: 1,
      rangi: "9E13F3",
      img1: ProductsCard11Rasm1,
      img2: ProductsCard11Rasm2,
      img3: ProductsCard11Rasm3,
      img4: ProductsCard11Rasm4,
      img5: ProductsCard11Rasm5,
      brand: 'nokia',
      priceee: "1-2",
      Yulduzcha: '⭐️⭐️⭐️⭐️',
      nnnnnaka: "nokia"
    },
    {
      id: 57,
      catagory1: "Toys",
      name: "Graphic Tablet Wacom Cintiq 16 (Black)",
      like: false,
      img: ShopHome1Home18,
      narx: "500.00",
      eski: "600.00",
      soni: 1,
      rangi: "0DA678",
      img1: ProductsCard12Rasm1,
      img2: ProductsCard12Rasm2,
      img3: ProductsCard12Rasm3,
      img4: ProductsCard12Rasm4,
      img5: ProductsCard12Rasm5,
      brand: 'samsung',
      priceee: "4-5",
      Yulduzcha: '⭐️⭐️⭐️',
      nnnnnaka: "samsung"
    },
    {
      id: 58,
      catagory1: "Books",
      name: "Huawei Nova 9, Qualcomm SM7325 Snapdragon 778G, ",
      like: false,
      img: ShopHome1Home19,
      narx: "270.00",
      eski: "300.00",
      soni: 1,
      rangi: "319DFF",
      img1: ProductsCard13Rasm1,
      img2: ProductsCard13Rasm2,
      img3: ProductsCard13Rasm3,
      img4: ProductsCard13Rasm4,
      img5: ProductsCard13Rasm5,
      brand: 'huawei',
      priceee: "2-3",
      Yulduzcha: '⭐️',
      nnnnnaka: "huawei"
    },
    {
      id: 59,
      catagory1: "Gifts",
      name: "Apple TV, 32GB Flash, WiFi, Bluetooth, Generation 5, 1080p",
      like: false,
      img: ShopHome1Home20,
      narx: "140.00",
      eski: "160.00",
      soni: 1,
      rangi: "17D1DD",
      img1: ProductsCard14Rasm1,
      img2: ProductsCard14Rasm2,
      img3: ProductsCard14Rasm3,
      img4: ProductsCard14Rasm4,
      img5: ProductsCard14Rasm5,
      brand: 'apple',
      priceee: "1-2",
      Yulduzcha: '⭐️⭐️',
      nnnnnaka: "apple"
    },
  ])
  let [filterData, setFilteData] = useState(shop);
  const [name, setName] = useState([]);
  const [plusminus, setPlusminus] = useState([])
  const [tab, setTab] = useState(2);
  const [filterText, setFilterText] = useState("");
  const [chekbook, setChekbook] = useState("");
  const [priceNarx, setPriceNarx] = useState("");
  const [yulduzchaas, setYulduzchaas] = useState("");
  const [narxchasiSS, setNarxchasiSS] = useState("");
  const [nnnnname, setNnnnname] = useState("");
  const [navbarCatagorysearch, setNavbarCatagorysearch] = useState();
  let handleCart = (Abdulazizbek_Savat) => {
    if (cart.filter((elem) => elem.id === Abdulazizbek_Savat.id).length === 0) {
      localStorage.setItem("localData", JSON.stringify([...cart, Abdulazizbek_Savat]));
      setCart(JSON.parse(localStorage.getItem("localData")) || []);
    } else {
      alert("This product has been added to the cart!");
    }
  };
  const handleLike = (id) => {
    setFilteData(
      filterData.map((item) =>
        item.id === id ? { ...item, like: !item.like } : item
      )
    )
  };
  // console.log(filterData.filter(i => i.like).map);
  // console.log(shop.map(home1 => home1.like ? 'red' : 'blue'));
  const [cart, setCart] = useState(
    JSON.parse(localStorage.getItem("localData")) || []
  );
  const refreshData = () => {
    setCart(JSON.parse(localStorage.getItem("localData")) || []);
  };
  function handleDeleteCart(id) {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        localStorage.setItem(
          "localData",
          JSON.stringify(cart.filter((elem) => elem.id !== id))
        );
        refreshData();
        Swal.fire("Deleted!", "Your file has been deleted.", "success");
      }
    });
  }
  function cartMinusFunc(item) {
    setFilteData(
      filterData.map((elem) =>
      elem.id === item ? { ...elem, soni: elem.soni - 1 } : elem
      )
    );
  }
  function cartPlusFunc(id) {
    setFilteData(
      filterData.map((elem) =>
        elem.id === id ? { ...elem, soni: elem.soni + 1 } : elem
      )
    );
  }
  return (
    <ABDULAZIZBEK_CONTEXT.Provider value={{
      navbarCatagorysearch,
      cartPlusFunc,
      cartMinusFunc,
      setNavbarCatagorysearch,
      handleDeleteCart,
      yulduzchaas,
      narxchasiSS,
      nnnnname,
      setNnnnname,
      setNarxchasiSS,
      setYulduzchaas,
      priceNarx,
      setPriceNarx,
      tab,
      setTab,
      filterText,
      chekbook,
      setChekbook,
      setFilterText,
      homeDivCatacogory2,
      catas3,
      catas2,
      catas1,
      setShop,
      search,
      setSearch,
      handleCart,
      cart,
      setCart,
      shop,
      setFilteData,
      handleLike,
      name,
      setName,
      filterData,
      setFilteData,
      plusminus,
      setPlusminus,
    }}>
      {children}
    </ABDULAZIZBEK_CONTEXT.Provider>
  )
}
export default Context;