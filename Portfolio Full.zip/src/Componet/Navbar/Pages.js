import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Home from "../Pages/Home/Home";
import Shop from "../Pages/Shop/Shop";
import Product from "../Pages/Product/Product";
import Cart from '../Pages/Card/Cart';
import Footer from '../Pages/Footer/Footer';
import NotFaund from "../Pages/NotFaund/NotFaund";
import LikePages from '../Pages/LikePages/LikePages';
function Pages() {
  return (
    <div>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/shop' element={<Shop />} />
        <Route path='/product/:id' element={<Product />} />
        <Route path='/cart' element={<Cart />} />
        <Route path='/Like' element={<LikePages />} />
        <Route path='*' element={<NotFaund/>} />
      </Routes>
      <Footer />
    </div>
  )
}
export default Pages;