import React, { useContext } from 'react';
import "./Navbar.css";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { AiFillInstagram, AiOutlineFacebook, AiTwotoneSetting } from "react-icons/ai";
import { BiLogoLinkedinSquare } from "react-icons/bi";
import { AiFillYoutube } from "react-icons/ai";
import { VscLocation } from "react-icons/vsc";
import { VscTwitter } from "react-icons/vsc";
import Rasm1 from "./Assets/Navbar1/Icons1.svg";
import Rasm2 from "./Assets/Navbar1/Icons2.svg";
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { FaBars } from "react-icons/fa";
import { BiSearch, BiSolidUser } from "react-icons/bi";
import { RiShuffleFill } from "react-icons/ri";
import { FcLikePlaceholder } from "react-icons/fc";
import { MdShoppingBasket } from "react-icons/md";
import Logo from "./Assets/Navbar2/Logo.png";
import { ABDULAZIZBEK_CONTEXT } from '../Context/Context';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import { Badge } from '@mui/material';
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
};
function Navbar() {
  const { setSearch, cart, filterData, setNavbarCatagorysearch, } = useContext(ABDULAZIZBEK_CONTEXT);
  const Cardd = useNavigate()
  const CardTravel = () => {
    Cardd("/cart")
  }
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <div className='Position_Fixed'>
      <div className='wdhqwhu'>
        <div className='Navbar1'>
          <div className='Navbar1Div'>
            <div className='Navbar1Div1'>
              <figure className='Navbar1DivFiguri'>
                <img className='Navbar1DivFiguriRasm' src={Rasm1} alt="" />
              </figure>
              <select className='Navbar1DivSelect'>
                <option>Language</option>
                <option>Eng</option>
                <option>O'zb</option>
              </select>
            </div>
            <div className='Navbar1Div2'>
              <figure className='Navbar1DivFiguri'>
                <img className='Navbar1DivFiguriRasm' src={Rasm2} alt="" />
              </figure>
              <select className='Navbar1DivSelect'>
                <option>Currency</option>
                <option name="Eng">Eng</option>
                <option name="O'zb">O'zb</option>
              </select>
            </div>
          </div>
          <div className='DivIconsNavbar1'>
            <div className='AMAMMMMMMMJHFUHB'>
              <NavLink to={"https://www.facebook.com/"}>
                <AiOutlineFacebook className='FacebookIcons' />
              </NavLink>
              <NavLink to={"https://www.instagram.com/abdulazizbek_amd/"}>
                <AiFillInstagram className='InstagramIcons' />
              </NavLink>
              <NavLink to={"https://twitter.com/?lang=oz"}>
                <VscTwitter className='TwitterIcons' />
              </NavLink>
              <NavLink to={"https://www.linkedin.com/checkpoint/lg/login-submit"}>
                <BiLogoLinkedinSquare className='LogoLinkedinSquareIcons' />
              </NavLink>
              <NavLink to={"https://www.youtube.com/"}>
                <AiFillYoutube className='YoutubeIcons' />
              </NavLink>
            </div>
          </div>
          <div className='Navbar1Div3'>
            <div className='Navbar1Div3Div1'>
              <VscLocation className='LocationIcons' />
              <p>Track Order</p>
            </div>
            <div className='Navbar1Div3Div2'>
              <ShoppingCartIcon className='ShoppingIcons' />
              <Link className='AAXX' to={"/Shop"}>
                <p className='kjefwuy'>
                  Shop
                </p>
              </Link>
              <span>{cart.length}</span>
            </div>
            <div className='Navbar1Div3Div3'>
              <AiTwotoneSetting className='SettingIcons' />
              <p className='wqmdiqj'>Settings</p>
            </div>
            <div className='Navbar1Div3Div4'>
              <span>
                FAQ
              </span>
            </div>
          </div>
        </div>
        <div className='Navbar2'>
          <div className='Navbar2Div'>
            <div className='Navbar2DivDiv1'>
              <FaBars className='Navbar2DivDiv1IconsBars' />
              <NavLink to={"/"}>
                <img src={Logo} alt="" className='LogoImg' />
              </NavLink>
            </div>
            <div className='Navbar2DivDiv2'>
              <input onChange={(e) => setSearch(e.target.value)} className='Navbar2DivDiv2Input' type="search" placeholder='Search for products' />
            </div>
            <div className='Navbar2DivDiv3'>
              <BiSearch onClick={() => setSearch("")} className='Navbar2DivDiv3IconsSearch' />
            </div>
            <div className='Navbar2DivDiv4'>
              <BiSolidUser className='UserIcons' />
              <RiShuffleFill className='ShuffleFillIcons' />
              <RiShuffleFill onClick={handleOpen} className='ShuffleFillIcons fwefweewmei' />
              <NavLink to={"/Like"}>
              <Badge badgeContent={filterData.filter((item) => item.like).length > 0 ? filterData.filter((item) => item.like).length :""} color="secondary">
                <FcLikePlaceholder className='LikeIcons' />
              </Badge>
              </NavLink>
              <div className='Navbar2DivDiv4Div1'>
                <MdShoppingBasket className='Navbar2DivDiv4Div1BasketIcons' />
                {/* <span className='jehiuwhyw'>{cart.reduce((a, b) => a + b.soni * (b.narx + 100 / 100), 0)}</span> */}
                <span className='jehiuwhyw' style={{ cursor: "pointer" }} onClick={() => CardTravel()}>{cart.reduce((a, b) => a + b.soni * (b.narx + 1 / 1), 0).toFixed(2)}$</span>
              </div>
            </div>
          </div>
        </div>
        <div>
          <Modal
            open={open}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
            onClose={handleClose}
          >
            <Box sx={style}>
              <div className='Navbar3Div fweewimfew'>
                <select className="Navbar3DivSelect1" name="">
                  <option className='' value="">TV & Audio </option>
                  <option className='' value="">Smart TVs</option>
                  <option className='' value="">4K TVs</option>
                  <option className='' value="">Full HD TVs</option>
                  <option className='' value="">Speakers</option>
                  <option className='' value="">Home Thetres</option>
                  <option className='' value="">Projectors</option>
                </select>
                <select className="Navbar3DivSelect2" name="">
                  <option className='' value="">Smartphones</option>
                  <option className='' value="">Batteries</option>
                  <option className='' value="">Cases</option>
                  <option className='' value="">Chargers</option>
                  <option className='' value="">Data Cables</option>
                  <option className='' value="">Headphones</option>
                  <option className='' value="">Screen Covers</option>
                </select>
                <select className="Navbar3DivSelect3" name="">
                  <option className='' value="">Laptops & PCs</option>
                  <option className='' value="">Laptops</option>
                  <option className='' value="">Desktops</option>
                  <option className='' value="">Monitors</option>
                  <option className='' value="">Keyboards</option>
                  <option className='' value="">Mouses</option>
                  <option className='' value="">Gaming</option>
                  <option className='' value="">Accessories</option>
                </select>
                <select className="Navbar3DivSelect4" name="">
                  <option className='' value="">Gadgets</option>
                  <option className='' value="">Smartwatches</option>
                  <option className='' value="">Fitness Bracelets</option>
                  <option className='' value="">VR Glasses</option>
                  <option className='' value="">Gaming</option>
                </select>
                <select className="Navbar3DivSelect5" name="">
                  <option className='' value="">Photo & Video</option>
                  <option className='' value="">Mirrorless Cameras</option>
                  <option className='' value="">DSL-R Cameras</option>
                  <option className='' value="">Compact Cameras</option>
                  <option className='' value="">Instant Cameras</option>
                  <option className='' value="">Accessories</option>
                </select>
                <select className="Navbar3DivSelect6" name="">
                  <option className='' value="">Gifts</option>
                  <option className='' value="">For Her</option>
                  <option className='' value="">For Him</option>
                  <option className='' value="">For Weddings</option>
                  <option className='' value="">For Anniversary</option>
                  <option className='' value="">For Baptise</option>
                  <option className='' value="">For Teens</option>
                </select>
                <select className="Navbar3DivSelect7" name="">
                  <option className='' value="">Books</option>
                  <option className='' value="">Biography</option>
                  <option className='' value="">Beletristic</option>
                  <option className='' value="">Science Fiction</option>
                  <option className='' value="">For Kids</option>
                  <option className='' value="">History</option>
                  <option className='' value="">Business</option>
                </select>
                <select className="Navbar3DivSelect8" name="">
                  <option className='' value="">Toys</option>
                  <option className='' value="">For Girls</option>
                  <option className='' value="">For Boys</option>
                  <option className='' value="">Under 3 Years</option>
                  <option className='' value="">Educational</option>
                </select>
              </div>
            </Box>
          </Modal>
        </div>
        <div className='Navbar3AMD fwelfewpo'>
          <div className='Navbar3Div'>
            <select className="Navbar3DivSelect1" name="">
              <option className='' value="">TV & Audio </option>
              <option className='' value="">Smart TVs</option>
              <option className='' value="">4K TVs</option>
              <option className='' value="">Full HD TVs</option>
              <option className='' value="">Speakers</option>
              <option className='' value="">Home Thetres</option>
              <option className='' value="">Projectors</option>
            </select>
            <select className="Navbar3DivSelect2" name="">
              <option className='' value="">Smartphones</option>
              <option className='' value="">Batteries</option>
              <option className='' value="">Cases</option>
              <option className='' value="">Chargers</option>
              <option className='' value="">Data Cables</option>
              <option className='' value="">Headphones</option>
              <option className='' value="">Screen Covers</option>
            </select>
            <select className="Navbar3DivSelect3" name="">
              <option className='' value="">Laptops & PCs</option>
              <option className='' value="">Laptops</option>
              <option className='' value="">Desktops</option>
              <option className='' value="">Monitors</option>
              <option className='' value="">Keyboards</option>
              <option className='' value="">Mouses</option>
              <option className='' value="">Gaming</option>
              <option className='' value="">Accessories</option>
            </select>
            <select className="Navbar3DivSelect4" name="">
              <option className='' value="">Gadgets</option>
              <option className='' value="">Smartwatches</option>
              <option className='' value="">Fitness Bracelets</option>
              <option className='' value="">VR Glasses</option>
              <option className='' value="">Gaming</option>
            </select>
            <select className="Navbar3DivSelect5" name="">
              <option className='' value="">Photo & Video</option>
              <option className='' value="">Mirrorless Cameras</option>
              <option className='' value="">DSL-R Cameras</option>
              <option className='' value="">Compact Cameras</option>
              <option className='' value="">Instant Cameras</option>
              <option className='' value="">Accessories</option>
            </select>
            <select className="Navbar3DivSelect6" name="">
              <option className='' value="">Gifts</option>
              <option className='' value="">For Her</option>
              <option className='' value="">For Him</option>
              <option className='' value="">For Weddings</option>
              <option className='' value="">For Anniversary</option>
              <option className='' value="">For Baptise</option>
              <option className='' value="">For Teens</option>
            </select>
            <select className="Navbar3DivSelect7" name="">
              <option className='' value="">Books</option>
              <option className='' value="">Biography</option>
              <option className='' value="">Beletristic</option>
              <option className='' value="">Science Fiction</option>
              <option className='' value="">For Kids</option>
              <option className='' value="">History</option>
              <option className='' value="">Business</option>
            </select>
            <select className="Navbar3DivSelect8" name="">
              <option className='' value="">Toys</option>
              <option className='' value="">For Girls</option>
              <option className='' value="">For Boys</option>
              <option className='' value="">Under 3 Years</option>
              <option className='' value="">Educational</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  )
}
export default Navbar;