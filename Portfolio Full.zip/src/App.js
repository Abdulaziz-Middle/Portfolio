import React from 'react';
import "./App.css";
import Navbar from './Componet/Navbar/Navbar';
import Pages from './Componet/Navbar/Pages';
function App() {
  return (
    <div className='Portfolio'>
      <Navbar/>
      <Pages/>
    </div>
  )
}
export default App